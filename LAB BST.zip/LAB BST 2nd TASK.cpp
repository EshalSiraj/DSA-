#include <iostream>
#include <string>
using namespace std;

class Employee {
public:
    int empNumber;
    string name;
    double salary;
    Employee* left;
    Employee* right;

    Employee(int number, string empName, double empSalary) {
        empNumber = number;
        name = empName;
        salary = empSalary;
        left = NULL;
        right = NULL;
    }
};

class EmployeeBST {
private:
    Employee* root;

    Employee* insert(Employee* root, int number, string name, double salary) {
        if (root == NULL) {
            return new Employee(number, name, salary);
        }

        if (number < root->empNumber) {
            root->left = insert(root->left, number, name, salary);
        } else if (number > root->empNumber) {
            root->right = insert(root->right, number, name, salary);
        }
        return root;
    }

    Employee* search(Employee* root, int number) {
        if (root == NULL || root->empNumber == number) {
            return root;
        }
        if (number < root->empNumber) {
            return search(root->left, number);
        } else {
            return search(root->right, number);
        }
    }

    Employee* deleteEmployee(Employee* root, int number) {
        if (root == NULL) {
            return root;
        }

        if (number < root->empNumber) {
            root->left = deleteEmployee(root->left, number);
        } else if (number > root->empNumber) {
            root->right = deleteEmployee(root->right, number);
        } else {
            if (root->left == NULL) {
                Employee* temp = root->right;
                delete root;
                return temp;
            } else if (root->right == NULL) {
                Employee* temp = root->left;
                delete root;
                return temp;
            }

            Employee* temp = minValueNode(root->right);
            root->empNumber = temp->empNumber;
            root->name = temp->name;
            root->salary = temp->salary;
            root->right = deleteEmployee(root->right, temp->empNumber);
        }
        return root;
    }

    Employee* minValueNode(Employee* node) {
        Employee* current = node;
        while (current && current->left != NULL) {
            current = current->left;
        }
        return current;
    }

    void inorder(Employee* root) {
        if (root != NULL) {
            inorder(root->left);
            cout << "Employee Number: " << root->empNumber << ", Name: " << root->name << ", Salary: " << root->salary << endl;
            inorder(root->right);
        }
    }

    void preorder(Employee* root) {
        if (root != NULL) {
            cout << "Employee Number: " << root->empNumber << ", Name: " << root->name << ", Salary: " << root->salary << endl;
            preorder(root->left);
            preorder(root->right);
        }
    }

    void postorder(Employee* root) {
        if (root != NULL) {
            postorder(root->left);
            postorder(root->right);
            cout << "Employee Number: " << root->empNumber << ", Name: " << root->name << ", Salary: " << root->salary << endl;
        }
    }

public:
    EmployeeBST() {
        root = NULL;
    }

    void insertEmployee(int number, string name, double salary) {
        root = insert(root, number, name, salary);
    }

    void searchEmployee(int number) {
        Employee* result = search(root, number);
        if (result != NULL) {
            cout << "Employee found - Number: " << result->empNumber << ", Name: " << result->name << ", Salary: " << result->salary << endl;
        } else {
            cout << "Employee with number " << number << " not found." << endl;
        }
    }

    void deleteEmployee(int number) {
        root = deleteEmployee(root, number);
        cout << "Employee with number " << number << " deleted if it existed." << endl;
    }

    void displayInorder() {
        cout << "In-order traversal:" << endl;
        inorder(root);
    }

    void displayPreorder() {
        cout << "Pre-order traversal:" << endl;
        preorder(root);
    }

    void displayPostorder() {
        cout << "Post-order traversal:" << endl;
        postorder(root);
    }
};

int main() {
    EmployeeBST bst;
    bst.insertEmployee(1, "Eshal", 5509340);
    bst.insertEmployee(2, "Fatima", 8992730);
    bst.insertEmployee(3, "Motashma", 836780);
    bst.insertEmployee(4, "Kashaf", 4587000);

    cout << endl;

    bst.displayInorder();
    cout << endl;

    bst.searchEmployee(3);
    bst.searchEmployee(5);

    bst.deleteEmployee(2);
    cout << endl;

    bst.displayInorder();
    cout << endl;

    bst.displayPreorder();
    cout << endl;

    bst.displayPostorder();

    return 0;
}

