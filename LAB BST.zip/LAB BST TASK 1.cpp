#include <iostream>
using namespace std;

class BST {
public:
    int value;
    BST *right, *left;

    BST(int val) {
        value = val;
        right = left = NULL;
    }

    BST* insert(BST* root, int val) {
        if (root == NULL)
            return new BST(val);

        if (val < root->value)
            root->left = insert(root->left, val);
        else if (val > root->value)
            root->right = insert(root->right, val);

        return root;
    }

    void inOrder(BST* root) {
        if (root != NULL) {
            inOrder(root->left);
            cout << root->value << " ";
            inOrder(root->right);
        }
    }

    void preOrder(BST* root) {
        if (root != NULL) {
            cout << root->value << " ";
            preOrder(root->left);
            preOrder(root->right);
        }
    }

    void postOrder(BST* root) {
        if (root != NULL) {
            postOrder(root->left);
            postOrder(root->right);
            cout << root->value << " ";
        }
    }
};

int main() {
    BST bst(0);
    BST* root = NULL;

    int values[] = {12, 7, 9, 10, 22, 24, 30, 18, 3, 14, 20};
    for (int i = 0; i < sizeof(values)/sizeof(values[0]); i++) {
        root = bst.insert(root, values[i]);
    }

    cout << "In-order traversal: ";
    bst.inOrder(root);
    cout << endl;

    cout << "Pre-order traversal: ";
    bst.preOrder(root);
    cout << endl;

    cout << "Post-order traversal: ";
    bst.postOrder(root);
    cout << endl;

    return 0;
}

