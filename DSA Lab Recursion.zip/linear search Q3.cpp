#include <iostream>
using namespace std;

int linearSearch(int arr[], int size, int index, int target) {
    if (index == size) return -1;
    if (arr[index] == target) return index;
    return linearSearch(arr, size, index + 1, target);
}

int main() {
    int arr[] = { 20, 30, 40, 50, 60};
    int size = sizeof(arr) / sizeof(arr[0]);
    int target = 40;

    int result = linearSearch(arr, size, 0, target);
    if (result != -1) {
        cout << "Element found at index " << result << endl;
    } else {
        cout << "Element not found in the array." << endl;
    }

    return 0;
}