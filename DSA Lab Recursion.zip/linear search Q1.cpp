#include <iostream>
using namespace std;

int main() {
    int tickets[10] = {13579, 26791, 26792, 33445, 55555, 62483, 77777, 79422, 85647, 93121};
    int winningNumber;
    bool isWinner = false;

    cout << "Enter this week's winning 5-digit number: ";
    cin >> winningNumber;

    for (int i = 0; i < 10; i++) {
        if (tickets[i] == winningNumber) {
            isWinner = true;
            break;
        }
    }

    if (isWinner==true) {
        cout << "Congratulations! You have a winning ticket." << endl;
    } else {
        cout << "Sorry, this ticket number did not win." << endl;
    }

    return 0;
}