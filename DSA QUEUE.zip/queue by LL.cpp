#include <iostream>
using namespace std;

class Node {
public:
    int data;
    Node* next;
};

class Queue {
private:
    Node* front;
    Node* rear;

public:
    Queue() {
        front =NULL;
        rear = NULL;
    }

    void enqueue(int value) {
        Node* temp = new Node();
        temp->data = value;
        temp->next = NULL;
        if (rear == NULL) {
            front = rear = temp;
            return;
        }
        rear->next = temp;
        rear = temp;
    }

    void dequeue() {
        if (front == NULL) {
            cout << "Queue is empty" << endl;
            return;
        }
        Node* temp = front;
        front = front->next;
        if (front == NULL) {
            rear = NULL;
        }
        delete temp;
    }

    void display() {
        if (front == NULL) {
            cout << "Queue is empty" << endl;
            return;
        }
        Node* temp = front;
        while (temp != NULL) {
            cout << temp->data <<endl;
            temp = temp->next;
        }
        cout << endl;
    }

    
    bool isEmpty() {
        if( front == NULL);
    }
};

int main() {
    Queue q;
    q.enqueue(10);
    q.enqueue(20);
    q.enqueue(30);
    q.display(); // Output: 10 20 30
    
    q.dequeue();
    q.display(); // Output: 20 30
    
    cout << "Front element: " << q.peek() << endl; // Output: 20
    cout << "Is queue empty? " << (q.isEmpty() ? "Yes" : "No") << endl; // Output: No
    
    return 0;
}

