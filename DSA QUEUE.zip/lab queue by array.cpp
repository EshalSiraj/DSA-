#include<iostream>
using namespace std;
class Queue { 
    int size = 5;
    int arr[5];
    int rear;
    int front;

public:
    Queue() {
        rear = -1;
        front = -1;
    } 

    void enqueue(int v) {
        if (rear == size - 1) {
            cout << "Queue is full" << endl;
    
        }
        else{
        arr[rear] = v;
        rear++;
		}
    }

    void dequeue() {
       
        cout << "Dequeued: " << arr[front] << endl;
    front++;
    }

    void empty() {
        if (front == rear) {
            cout << "Queue is empty" << endl;
        }
    }

    void full() {
        if (rear == size - 1) {
            cout << "Queue is full" << endl;
        }
    }

    void display() {
    	cout<<"Elements of queue:"<<endl;
        for (int i = front; i <= rear; i++) {
            cout << arr[i] << endl;    
        }
    }
};

int main() {
    Queue q;
    q.enqueue(10);
    q.enqueue(20);
	q.enqueue(30);
    q.enqueue(40);
    q.enqueue(50);  
    q.display();
    q.dequeue();
    q.dequeue();
    
    q.display();
    q.empty();
	 q.full();
    return 0;
}
